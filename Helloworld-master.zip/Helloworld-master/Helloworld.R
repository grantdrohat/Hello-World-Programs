# tutorialspoint.com
mystring <- "Hello, World!"
print (mystring)

