# stackoverflow.com
puts "Hello, World!"