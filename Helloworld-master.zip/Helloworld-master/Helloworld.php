<!-- www.sitepoint.com -->
<?php print "Hello, World!"; ?>